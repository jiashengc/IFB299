from django.apps import AppConfig


class SplashConfig(AppConfig):
    name = 'splash'
